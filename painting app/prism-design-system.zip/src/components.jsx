/* ============================================================
   PRISM — React components
   Zero dependencies. Styling lives in glass.css; these are thin,
   accessible wrappers that keep class names and ARIA in one place.

   import './tokens.css'
   import './glass.css'
   import { PrismRoot, Button, Panel, ToolRail } from './components'
   ============================================================ */

import React, { useCallback, useEffect, useId, useRef, useState } from 'react'

const cx = (...parts) => parts.filter(Boolean).join(' ')

/* ============================================================
   ROOT — mount once, wraps the app
   Renders the blob field and grain that every glass surface
   refracts. Glass without this looks like flat gray boxes.
   ============================================================ */
export function PrismRoot({ theme = 'dark', blobs = true, grain = true, className, children, ...rest }) {
  return (
    <div className={cx('prism', className)} data-theme={theme} {...rest}>
      {blobs && <BlobField />}
      {grain && <div className="prism-grain" aria-hidden="true" />}
      <div style={{ position: 'relative', zIndex: 'var(--z-content)' }}>{children}</div>
    </div>
  )
}

export function BlobField({ count = 6 }) {
  return (
    <div className="prism-blobs" aria-hidden="true">
      {Array.from({ length: count }, (_, i) => (
        <div key={i} className={`prism-blob prism-blob--${i + 1}`} />
      ))}
    </div>
  )
}

/* ============================================================
   GLASS — the primitive everything composes from
   tier: 1 subtle | 2 default | 3 modal
   iri:  animated iridescent 1px edge
   sheen: light band sweeps across on hover
   ============================================================ */
export function Glass({ tier = 2, iri = false, sheen = false, as: Tag = 'div', className, children, ...rest }) {
  return (
    <Tag
      className={cx('glass', tier !== 2 && `glass--${tier}`, iri && 'glass--iri', sheen && 'glass--sheen', className)}
      {...rest}
    >
      {children}
    </Tag>
  )
}

export function Panel({ title, action, tier = 2, iri, className, children, ...rest }) {
  return (
    <Glass tier={tier} iri={iri} className={cx('panel', className)} {...rest}>
      {(title || action) && (
        <div className="panel__head">
          {title && <h3 className="panel__title">{title}</h3>}
          {action}
        </div>
      )}
      {children}
    </Glass>
  )
}

export function Card({ media, className, children, ...rest }) {
  return (
    <Glass sheen className={cx('card', className)} {...rest}>
      {media && <div className="card__media">{media}</div>}
      <div className="card__body">{children}</div>
    </Glass>
  )
}

/* ============================================================
   BUTTON
   variant: 'glass' | 'iri' | 'ghost'
   size:    'sm' | 'md' | 'lg'
   ============================================================ */
export function Button({
  variant = 'glass',
  size = 'md',
  icon = false,
  block = false,
  className,
  children,
  ...rest
}) {
  return (
    <button
      type="button"
      className={cx(
        'btn',
        variant !== 'glass' && `btn--${variant}`,
        size !== 'md' && `btn--${size}`,
        icon && 'btn--icon',
        block && 'btn--block',
        className
      )}
      {...rest}
    >
      {children}
    </button>
  )
}

export const IconButton = ({ label, children, ...rest }) => (
  <Button icon aria-label={label} title={label} {...rest}>
    {children}
  </Button>
)

/* ============================================================
   TOOL RAIL — the painting app's spine
   Controlled: pass `value` and `onChange`.
   Keyboard: arrow keys move between tools (roving tabindex),
   which is what a real tool palette owes its users.
   ============================================================ */
export function ToolRail({ tools, value, onChange, orientation = 'vertical', className, ...rest }) {
  const railRef = useRef(null)
  const horizontal = orientation === 'horizontal'

  const onKeyDown = (e) => {
    const next = horizontal ? 'ArrowRight' : 'ArrowDown'
    const prev = horizontal ? 'ArrowLeft' : 'ArrowUp'
    if (e.key !== next && e.key !== prev) return
    e.preventDefault()
    const i = tools.findIndex((t) => t.id === value)
    const d = e.key === next ? 1 : -1
    const target = tools[(i + d + tools.length) % tools.length]
    onChange?.(target.id)
    railRef.current?.querySelector(`[data-tool="${target.id}"]`)?.focus()
  }

  return (
    <div
      ref={railRef}
      role="toolbar"
      aria-orientation={orientation}
      aria-label="Tools"
      onKeyDown={onKeyDown}
      className={cx('glass', 'rail', horizontal && 'rail--h', className)}
      {...rest}
    >
      {tools.map((t) => (
        <button
          key={t.id}
          data-tool={t.id}
          className="tool"
          aria-pressed={value === t.id}
          aria-label={t.label}
          title={t.shortcut ? `${t.label} (${t.shortcut})` : t.label}
          tabIndex={value === t.id ? 0 : -1}
          onClick={() => onChange?.(t.id)}
        >
          {t.icon}
          {t.shortcut && <span className="tool__badge">{t.shortcut}</span>}
        </button>
      ))}
    </div>
  )
}

/* ============================================================
   COLOR
   ============================================================ */
export function Swatch({ color, selected = false, label, size = 34, ...rest }) {
  return (
    <button
      className="swatch"
      style={{ width: size, height: size }}
      aria-pressed={selected}
      aria-label={label || color}
      title={label || color}
      {...rest}
    >
      <span className="swatch__fill" style={{ background: color }} />
    </button>
  )
}

export function SwatchGrid({ colors, value, onChange, size = 34 }) {
  return (
    <div style={{ display: 'flex', flexWrap: 'wrap', gap: 'var(--sp-2)' }} role="group" aria-label="Palette">
      {colors.map((c) => (
        <Swatch key={c} color={c} size={size} selected={value === c} onClick={() => onChange?.(c)} />
      ))}
    </div>
  )
}

/**
 * HueRing — drag anywhere on the ring to set hue.
 * Also arrow-key steppable, because a color picker that is
 * mouse-only is a color picker half your users cannot reach.
 */
export function HueRing({ hue = 0, onChange, sat = 82, light = 60, size = 168 }) {
  const ref = useRef(null)
  const dragging = useRef(false)

  const setFromEvent = useCallback(
    (e) => {
      const el = ref.current
      if (!el) return
      const r = el.getBoundingClientRect()
      const cx0 = r.left + r.width / 2
      const cy0 = r.top + r.height / 2
      const point = e.touches?.[0] ?? e
      const deg = (Math.atan2(point.clientY - cy0, point.clientX - cx0) * 180) / Math.PI + 90
      onChange?.(Math.round((deg + 360) % 360))
    },
    [onChange]
  )

  useEffect(() => {
    const move = (e) => dragging.current && setFromEvent(e)
    const up = () => (dragging.current = false)
    window.addEventListener('pointermove', move)
    window.addEventListener('pointerup', up)
    return () => {
      window.removeEventListener('pointermove', move)
      window.removeEventListener('pointerup', up)
    }
  }, [setFromEvent])

  const rad = ((hue - 90) * Math.PI) / 180
  const radius = size / 2 - 13
  const color = `hsl(${hue} ${sat}% ${light}%)`

  return (
    <div
      ref={ref}
      className="hue-ring"
      style={{ width: size, height: size }}
      role="slider"
      tabIndex={0}
      aria-label="Hue"
      aria-valuemin={0}
      aria-valuemax={359}
      aria-valuenow={hue}
      aria-valuetext={`${hue} degrees`}
      onPointerDown={(e) => {
        dragging.current = true
        setFromEvent(e)
      }}
      onKeyDown={(e) => {
        const step = e.shiftKey ? 10 : 1
        if (e.key === 'ArrowRight' || e.key === 'ArrowUp') onChange?.((hue + step) % 360)
        if (e.key === 'ArrowLeft' || e.key === 'ArrowDown') onChange?.((hue - step + 360) % 360)
      }}
    >
      <span
        className="hue-ring__thumb"
        style={{
          left: `${50 + (Math.cos(rad) * radius * 100) / size}%`,
          top: `${50 + (Math.sin(rad) * radius * 100) / size}%`,
          background: color,
        }}
      />
      <div className="hue-ring__readout">
        <div style={{ width: 40, height: 40, borderRadius: 12, background: color, margin: '0 auto 8px', boxShadow: 'var(--shadow-sm), var(--glass-spec)' }} />
        <span className="mono">{hslToHex(hue, sat, light)}</span>
      </div>
    </div>
  )
}

function hslToHex(h, s, l) {
  s /= 100
  l /= 100
  const k = (n) => (n + h / 30) % 12
  const a = s * Math.min(l, 1 - l)
  const f = (n) => Math.round(255 * (l - a * Math.max(-1, Math.min(k(n) - 3, Math.min(9 - k(n), 1)))))
  return '#' + [f(0), f(8), f(4)].map((v) => v.toString(16).padStart(2, '0')).join('').toUpperCase()
}

/* ============================================================
   SLIDER
   --slider-pct drives the WebKit track fill. Keep it in sync or
   the gradient and the thumb disagree, which looks broken.
   ============================================================ */
export function Slider({ label, value, min = 0, max = 100, step = 1, unit = '', onChange, ...rest }) {
  const id = useId()
  const pct = ((value - min) / (max - min)) * 100
  return (
    <div className="slider-row">
      {label && (
        <label className="slider-row__label" htmlFor={id}>
          <span>{label}</span>
          <span className="mono">
            {value}
            {unit}
          </span>
        </label>
      )}
      <input
        id={id}
        type="range"
        className="slider"
        style={{ '--slider-pct': `${pct}%`, gridColumn: '1 / -1' }}
        min={min}
        max={max}
        step={step}
        value={value}
        onChange={(e) => onChange?.(Number(e.target.value))}
        {...rest}
      />
    </div>
  )
}

/* ============================================================
   SEGMENTED / TOGGLE / INPUT
   ============================================================ */
export function Segmented({ items, value, onChange, className, ...rest }) {
  return (
    <div role="tablist" className={cx('glass', 'glass--1', 'segmented', className)} {...rest}>
      {items.map((it) => (
        <button
          key={it.id}
          role="tab"
          className="segmented__item"
          aria-selected={value === it.id}
          onClick={() => onChange?.(it.id)}
        >
          {it.label}
        </button>
      ))}
    </div>
  )
}

export function Toggle({ checked = false, onChange, label, ...rest }) {
  return (
    <button
      role="switch"
      className="toggle"
      aria-checked={checked}
      aria-label={label}
      onClick={() => onChange?.(!checked)}
      {...rest}
    />
  )
}

export const Input = ({ className, ...rest }) => <input className={cx('input', className)} {...rest} />

/* ============================================================
   LAYERS
   ============================================================ */
export function LayerRow({ layer, selected, onSelect, onToggleVisible }) {
  return (
    <div className="layer" aria-selected={selected} onClick={() => onSelect?.(layer.id)}>
      <div className="layer__thumb" style={{ background: layer.thumb }} />
      <div>
        <div className="layer__name">{layer.name}</div>
        <div className="layer__meta">
          {layer.blend} · {layer.opacity}%
        </div>
      </div>
      <IconButton
        size="sm"
        variant="ghost"
        label={layer.visible ? `Hide ${layer.name}` : `Show ${layer.name}`}
        onClick={(e) => {
          e.stopPropagation()
          onToggleVisible?.(layer.id)
        }}
      >
        {layer.visible ? <EyeIcon /> : <EyeOffIcon />}
      </IconButton>
    </div>
  )
}

/* ============================================================
   MODAL — focus trap + escape + scroll lock
   ============================================================ */
export function Modal({ open, onClose, title, children, footer }) {
  const ref = useRef(null)

  useEffect(() => {
    if (!open) return
    const onKey = (e) => e.key === 'Escape' && onClose?.()
    document.addEventListener('keydown', onKey)
    const prev = document.body.style.overflow
    document.body.style.overflow = 'hidden'
    ref.current?.querySelector('button, [href], input, select, textarea')?.focus()
    return () => {
      document.removeEventListener('keydown', onKey)
      document.body.style.overflow = prev
    }
  }, [open, onClose])

  if (!open) return null
  return (
    <div className="scrim" onClick={onClose}>
      <div
        ref={ref}
        role="dialog"
        aria-modal="true"
        aria-label={title}
        className="glass glass--3 glass--iri modal"
        onClick={(e) => e.stopPropagation()}
      >
        {title && <h2 className="t-h2" style={{ marginBottom: 'var(--sp-3)' }}>{title}</h2>}
        {children}
        {footer && (
          <div style={{ display: 'flex', gap: 'var(--sp-2)', justifyContent: 'flex-end', marginTop: 'var(--sp-5)' }}>
            {footer}
          </div>
        )}
      </div>
    </div>
  )
}

export function Toast({ children, icon, className, ...rest }) {
  return (
    <div role="status" className={cx('glass', 'glass--3', 'toast', className)} {...rest}>
      {icon}
      <span className="t-sm" style={{ color: 'var(--text-hi)' }}>{children}</span>
    </div>
  )
}

export const Chip = ({ iri, className, children, ...rest }) => (
  <span className={cx('glass', 'glass--1', 'chip', iri && 'chip--iri', className)} {...rest}>
    {children}
  </span>
)

export const Divider = () => <hr className="hr" />

/* ============================================================
   ICONS — 20px, 1.6 stroke, round caps.
   Consistent stroke weight matters more than icon choice.
   ============================================================ */
const svg = (d, extra) => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
    {d}
    {extra}
  </svg>
)
export const BrushIcon = () => svg(<path d="M9.5 14.5 4 20s3 .5 4.5-1 1-4.5 1-4.5Z" />, <path d="M14 4.5 9.5 14.5l0 0L20 4c-1.5-1.5-4.5-1-6 .5Z" />)
export const EraserIcon = () => svg(<path d="m4 16 6.5-6.5a2 2 0 0 1 2.8 0l4.2 4.2a2 2 0 0 1 0 2.8L15 19H8l-4-3Z" />, <path d="M9 19h11" />)
export const FillIcon = () => svg(<path d="m11 3 8 8-7 7-8-8 7-7Z" />, <path d="M20 14.5s2 2.2 2 3.5a2 2 0 1 1-4 0c0-1.3 2-3.5 2-3.5Z" />)
export const EyedropIcon = () => svg(<path d="m17 3 4 4-9 9-4-4 9-9Z" />, <path d="M8 12 4 16v4h4l4-4" />)
export const ShapeIcon = () => svg(<circle cx="9" cy="9" r="5" />, <rect x="11" y="11" width="9" height="9" rx="2" />)
export const TextIcon = () => svg(<path d="M5 6h14M12 6v13" />)
export const LayersIcon = () => svg(<path d="m12 3 9 5-9 5-9-5 9-5Z" />, <path d="m3 13 9 5 9-5M3 17l9 5 9-5" />)
export const UndoIcon = () => svg(<path d="M9 14 4 9l5-5" />, <path d="M4 9h11a5 5 0 0 1 0 10h-4" />)
export const RedoIcon = () => svg(<path d="m15 14 5-5-5-5" />, <path d="M20 9H9a5 5 0 0 0 0 10h4" />)
export const EyeIcon = () => svg(<path d="M2 12s3.6-6 10-6 10 6 10 6-3.6 6-10 6-10-6-10-6Z" />, <circle cx="12" cy="12" r="2.6" />)
export const EyeOffIcon = () => svg(<path d="M3 3l18 18" />, <path d="M10.6 6.2A9.9 9.9 0 0 1 12 6c6.4 0 10 6 10 6a17 17 0 0 1-3.3 3.8M6.3 8.3A17 17 0 0 0 2 12s3.6 6 10 6a9.7 9.7 0 0 0 3.5-.6" />)
export const SparkIcon = () => svg(<path d="M12 3v4M12 17v4M3 12h4M17 12h4M5.6 5.6l2.8 2.8M15.6 15.6l2.8 2.8M18.4 5.6l-2.8 2.8M8.4 15.6l-2.8 2.8" />)

/* ============================================================
   THEME HOOK
   ============================================================ */
export function useTheme(initial = 'dark') {
  const [theme, setTheme] = useState(initial)
  useEffect(() => {
    document.documentElement.setAttribute('data-theme', theme)
  }, [theme])
  return [theme, setTheme, () => setTheme((t) => (t === 'dark' ? 'light' : 'dark'))]
}
