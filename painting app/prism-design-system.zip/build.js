const fs = require('fs');
const css = fs.readFileSync('src/tokens.css','utf8') + '\n\n' + fs.readFileSync('src/glass.css','utf8');
const html = fs.readFileSync('showcase.template.html','utf8').replace('/*__CSS__*/', css);
fs.writeFileSync('prism-showcase.html', html);
console.log('built prism-showcase.html', (html.length/1024).toFixed(1)+'kb');
