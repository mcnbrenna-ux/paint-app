/** ============================================================
 *  PRISM — Tailwind config
 *  Maps every token in tokens.css to a utility.
 *  Tokens stay the single source of truth; Tailwind just
 *  exposes them. Never hardcode a hex in a className.
 *  Works with Tailwind v3. For v4, see the @theme block at the
 *  bottom of this file.
 *  ============================================================ */

/** @type {import('tailwindcss').Config} */
module.exports = {
  darkMode: ['class', '[data-theme="dark"]'],
  content: ['./src/**/*.{js,jsx,ts,tsx,html}', './index.html'],
  theme: {
    extend: {
      colors: {
        ink: {
          900: 'var(--ink-900)',
          800: 'var(--ink-800)',
          700: 'var(--ink-700)',
          600: 'var(--ink-600)',
        },
        paper: {
          100: 'var(--paper-100)',
          200: 'var(--paper-200)',
          300: 'var(--paper-300)',
        },
        iri: {
          magenta: 'var(--iri-magenta)',
          violet: 'var(--iri-violet)',
          cyan: 'var(--iri-cyan)',
          mint: 'var(--iri-mint)',
          gold: 'var(--iri-gold)',
          blush: 'var(--iri-blush)',
        },
        glass: {
          1: 'var(--glass-1-fill)',
          2: 'var(--glass-2-fill)',
          3: 'var(--glass-3-fill)',
        },
        edge: {
          1: 'var(--glass-1-edge)',
          2: 'var(--glass-2-edge)',
          3: 'var(--glass-3-edge)',
        },
        text: {
          hi: 'var(--text-hi)',
          mid: 'var(--text-mid)',
          low: 'var(--text-low)',
          ghost: 'var(--text-ghost)',
        },
      },

      fontFamily: {
        display: ['Fraunces', 'Iowan Old Style', 'Georgia', 'serif'],
        ui: ['Schibsted Grotesk', 'Helvetica Neue', 'sans-serif'],
        mono: ['Martian Mono', 'ui-monospace', 'SF Mono', 'monospace'],
      },

      fontSize: {
        micro: ['var(--fs-micro)', { lineHeight: '1.4', letterSpacing: 'var(--tr-micro)' }],
        xs: ['var(--fs-xs)', { lineHeight: '1.45' }],
        sm: ['var(--fs-sm)', { lineHeight: '1.5' }],
        base: ['var(--fs-body)', { lineHeight: 'var(--lh-body)' }],
        h3: ['var(--fs-h3)', { lineHeight: '1.35' }],
        h2: ['var(--fs-h2)', { lineHeight: 'var(--lh-snug)', letterSpacing: 'var(--tr-h)' }],
        h1: ['var(--fs-h1)', { lineHeight: 'var(--lh-snug)', letterSpacing: 'var(--tr-h)' }],
        display: ['var(--fs-display)', { lineHeight: 'var(--lh-tight)', letterSpacing: 'var(--tr-display)' }],
      },

      letterSpacing: {
        display: 'var(--tr-display)',
        heading: 'var(--tr-h)',
        body: 'var(--tr-body)',
        label: 'var(--tr-label)',
        micro: 'var(--tr-micro)',
      },

      borderRadius: {
        xs: 'var(--r-xs)',
        sm: 'var(--r-sm)',
        md: 'var(--r-md)',
        lg: 'var(--r-lg)',
        xl: 'var(--r-xl)',
        '2xl': 'var(--r-2xl)',
        pill: 'var(--r-pill)',
      },

      spacing: {
        1: 'var(--sp-1)',
        2: 'var(--sp-2)',
        3: 'var(--sp-3)',
        4: 'var(--sp-4)',
        5: 'var(--sp-5)',
        6: 'var(--sp-6)',
        7: 'var(--sp-7)',
        8: 'var(--sp-8)',
        9: 'var(--sp-9)',
      },

      backdropBlur: {
        g1: 'var(--glass-1-blur)',
        g2: 'var(--glass-2-blur)',
        g3: 'var(--glass-3-blur)',
      },

      backdropSaturate: {
        glass: 'var(--glass-sat)',
      },

      boxShadow: {
        sm: 'var(--shadow-sm)',
        md: 'var(--shadow-md)',
        lg: 'var(--shadow-lg)',
        xl: 'var(--shadow-xl)',
        spec: 'var(--glass-spec)',
        'spec-strong': 'var(--glass-spec-strong)',
        bounce: 'var(--glass-bounce)',
        'glow-cyan': 'var(--glow-cyan)',
        'glow-magenta': 'var(--glow-magenta)',
        /* Composite: the one you actually want on a panel */
        glass: 'var(--shadow-md), var(--glass-spec), var(--glass-bounce)',
        'glass-lg': 'var(--shadow-xl), var(--glass-spec-strong), var(--glass-bounce)',
      },

      backgroundImage: {
        iri: 'var(--iri-line)',
        'iri-conic': 'conic-gradient(from var(--iri-angle), var(--iri-sweep))',
        grain:
          "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='240' height='240'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.85' numOctaves='4' stitchTiles='stitch'/%3E%3CfeColorMatrix type='saturate' values='0'/%3E%3C/filter%3E%3Crect width='240' height='240' filter='url(%23n)'/%3E%3C/svg%3E\")",
      },

      transitionTimingFunction: {
        out: 'var(--ease-out)',
        'in-out': 'var(--ease-in-out)',
        spring: 'var(--ease-spring)',
      },

      transitionDuration: {
        instant: '90ms',
        fast: '160ms',
        base: '280ms',
        slow: '520ms',
      },

      keyframes: {
        'blob-drift': {
          '0%': { transform: 'translate3d(0,0,0) scale(1)' },
          '33%': { transform: 'translate3d(6vw,-4vh,0) scale(1.12)' },
          '66%': { transform: 'translate3d(-4vw,5vh,0) scale(0.94)' },
          '100%': { transform: 'translate3d(3vw,3vh,0) scale(1.06)' },
        },
        'iri-rotate': { to: { '--iri-angle': '360deg' } },
        'iri-shift': { from: { backgroundPosition: '0% 0' }, to: { backgroundPosition: '100% 0' } },
        rise: {
          from: { opacity: '0', transform: 'translateY(20px)', filter: 'blur(6px)' },
          to: { opacity: '1', transform: 'none', filter: 'none' },
        },
        'modal-in': { from: { opacity: '0', transform: 'translateY(18px) scale(0.96)' } },
      },

      animation: {
        'blob-drift': 'blob-drift var(--dur-drift) var(--ease-in-out) infinite alternate',
        'iri-rotate': 'iri-rotate var(--dur-sweep) linear infinite',
        'iri-shift': 'iri-shift 6s var(--ease-in-out) infinite alternate',
        rise: 'rise var(--dur-slow) var(--ease-out) forwards',
        'modal-in': 'modal-in var(--dur-base) var(--ease-spring)',
      },

      zIndex: {
        blobs: '0',
        grain: '1',
        content: '10',
        rail: '40',
        popover: '60',
        modal: '80',
        toast: '100',
      },
    },
  },

  plugins: [
    /* Composite glass utilities. These exist because writing
       `bg-glass-2 backdrop-blur-g2 backdrop-saturate-glass
        border border-edge-2 shadow-glass` on every panel is
       how design systems rot. One class, one decision. */
    function ({ addComponents, addUtilities }) {
      addComponents({
        '.glass-1': {
          backgroundColor: 'var(--glass-1-fill)',
          backdropFilter: 'blur(var(--glass-1-blur)) saturate(var(--glass-sat))',
          WebkitBackdropFilter: 'blur(var(--glass-1-blur)) saturate(var(--glass-sat))',
          border: '1px solid var(--glass-1-edge)',
          boxShadow: 'var(--shadow-sm), var(--glass-spec), var(--glass-bounce)',
          isolation: 'isolate',
        },
        '.glass-2': {
          backgroundColor: 'var(--glass-2-fill)',
          backdropFilter: 'blur(var(--glass-2-blur)) saturate(var(--glass-sat))',
          WebkitBackdropFilter: 'blur(var(--glass-2-blur)) saturate(var(--glass-sat))',
          border: '1px solid var(--glass-2-edge)',
          boxShadow: 'var(--shadow-md), var(--glass-spec), var(--glass-bounce)',
          isolation: 'isolate',
        },
        '.glass-3': {
          backgroundColor: 'var(--glass-3-fill)',
          backdropFilter: 'blur(var(--glass-3-blur)) saturate(var(--glass-sat))',
          WebkitBackdropFilter: 'blur(var(--glass-3-blur)) saturate(var(--glass-sat))',
          border: '1px solid var(--glass-3-edge)',
          boxShadow: 'var(--shadow-xl), var(--glass-spec-strong), var(--glass-bounce)',
          isolation: 'isolate',
        },
      })
      addUtilities({
        '.iri-edge': {
          position: 'relative',
          '&::before': {
            content: '""',
            position: 'absolute',
            inset: '0',
            borderRadius: 'inherit',
            padding: '1px',
            background: 'conic-gradient(from var(--iri-angle), var(--iri-sweep))',
            WebkitMask: 'linear-gradient(#000 0 0) content-box, linear-gradient(#000 0 0)',
            WebkitMaskComposite: 'xor',
            mask: 'linear-gradient(#000 0 0) content-box, linear-gradient(#000 0 0)',
            maskComposite: 'exclude',
            pointerEvents: 'none',
            animation: 'iri-rotate var(--dur-sweep) linear infinite',
          },
        },
        '.iri-text': {
          background: 'var(--iri-line)',
          backgroundSize: '200% 100%',
          WebkitBackgroundClip: 'text',
          backgroundClip: 'text',
          color: 'transparent',
        },
        '.tnum': { fontVariantNumeric: 'tabular-nums' },
      })
    },
  ],
}

/* ------------------------------------------------------------
   TAILWIND V4
   v4 reads theme from CSS, not JS. If you are on v4, delete this
   config and put this in your entry CSS instead:

   @import "tailwindcss";
   @import "./src/tokens.css";
   @import "./src/glass.css";

   @theme {
     --color-ink-900: var(--ink-900);
     --color-iri-magenta: var(--iri-magenta);
     --color-iri-violet: var(--iri-violet);
     --color-iri-cyan: var(--iri-cyan);
     --color-iri-mint: var(--iri-mint);
     --color-iri-gold: var(--iri-gold);
     --color-iri-blush: var(--iri-blush);
     --font-display: 'Fraunces', Georgia, serif;
     --font-ui: 'Schibsted Grotesk', sans-serif;
     --font-mono: 'Martian Mono', monospace;
     --radius-lg: var(--r-lg);
     --radius-xl: var(--r-xl);
     --ease-out: cubic-bezier(0.16, 1, 0.3, 1);
   }
   ------------------------------------------------------------ */
